package com.lil.demo;
 
public class Testing {

	public static void main(String[] args) throws Exception {
		System.out.println("dabfdgd123900".matches("[a-zA-Z]"));
	}

}
