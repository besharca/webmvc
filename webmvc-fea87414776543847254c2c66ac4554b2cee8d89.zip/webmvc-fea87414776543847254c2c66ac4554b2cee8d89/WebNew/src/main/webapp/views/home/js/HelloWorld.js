/**
 * 
 */
function calc(numA,numB){
	return numA+numB;
}

